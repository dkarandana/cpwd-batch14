	var studentData = new Array("Samal","Supun","Sadun","Kasun","Amal");

	var myFunc = function( name, index ){
		console.log(name,index)
	};
		
	studentData.forEach( myFunc );
	document.addEventListener('DOMContentLoaded',function(){
		console.log('DOM Loaded')
	var studentList = document.getElementById("student-list");
	
	if(studentList && studentData ){
		
		studentData.forEach(function(name,i){
		var para = document.createElement( 'li' );
		
		var paraText = document.createTextNode( '++i + ' ):
		
		studentEle.appendChild( studentTextNode );
		studentList.appendChild( studentEle );
		});
	}
	});

                     