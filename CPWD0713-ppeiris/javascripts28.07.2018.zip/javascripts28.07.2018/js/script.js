
//console.log("script");

/*
var cpwd;
var firstname="Pesantha";
var lastname="Peiris";
var FullName;

	FullName = firstname + " " +lastname;

	console.log(FullName);
	console.log(typeof FullName);
*/ /*

function getFullName(){

		var firstname="Pesantha";
		var lastname="Peiris";
		var FullName;

			FullName = firstname + " " +lastname;
			console.log(FullName);
}

getFullName();
getFullName();
*/ 

function getFullName(firstname, lastname){

		var FullName;

			FullName = firstname + " " +lastname;
			return "Full Name is ", FullName;
}

var person1= getFullName("Pesantha", "Peiris");
console.log(person1);
var person2= getFullName("Sunil", "Samarakoon");
console.log(person2);
